# Figuras da seção Resultados

As Figuras 1 e 2 (`figs/grafo_IMC_computacao.png` e `figs/grafo_IMC_computacao_matematica.png`) são
capturas da interface do sistema, com o filtro de 2016 a 2026 e a cor por área.

A Figura 3 (`figs/fig22_forca_por_destino.pdf`) é gerada por estes scripts, a partir dos CSVs do projeto
(`rede-imc/backend/data/raw`), restritos a 2016–2026:

```
python gerar_periodo.py ../../rede-imc/backend/data/raw dados_2016_2026
python gerar_figuras_ccmat.py dados_2016_2026 ../figs
```

O segundo script também gera as figuras 20, 21 e 23, que não são mais usadas no artigo.
Requer `networkx` e `matplotlib`.
