"""Gera uma copia dos 4 CSVs do projeto restrita as atividades de 2016 a 2026 (campo 'ano').
Uso: python gerar_periodo.py <pasta_csv_origem> <pasta_destino>"""
import csv, sys, json, os, shutil
csv.field_size_limit(10**9)
orig, dest = sys.argv[1], sys.argv[2]
INI, FIM = 2016, 2026
def ok(r):
    y = r['ano'][:4]
    return y.isdigit() and INI <= int(y) <= FIM
with open(os.path.join(orig, 'dataset_atividades_IMC.csv'), encoding='utf-8-sig', newline='') as f:
    rd = csv.DictReader(f); campos = rd.fieldnames; ativ = list(rd)
validas = {r['id_atividade'] for r in ativ if ok(r)}
with open(os.path.join(dest, 'dataset_atividades_IMC.csv'), 'w', encoding='utf-8', newline='') as f:
    w = csv.DictWriter(f, fieldnames=campos); w.writeheader(); w.writerows(r for r in ativ if r['id_atividade'] in validas)
with open(os.path.join(orig, 'dataset_saida_IMC.csv'), encoding='utf-8-sig', newline='') as f:
    rd = csv.DictReader(f); campos = rd.fieldnames; saida = list(rd)
n = 0
with open(os.path.join(dest, 'dataset_saida_IMC.csv'), 'w', encoding='utf-8', newline='') as f:
    w = csv.DictWriter(f, fieldnames=campos); w.writeheader()
    for r in saida:
        bruto = [[x for x in ids if x in validas] for ids in json.loads(r['vetor bruto'])]
        cont = [len(ids) for ids in bruto]
        if sum(cont) == 0:
            continue
        r = dict(r); r['vetor bruto'] = json.dumps(bruto, ensure_ascii=False); r['vetor contagem'] = json.dumps(cont)
        w.writerow(r); n += 1
for nome in ('dataset_entrada_IMC.csv', 'dataset_completo_UNIFEI.csv'):
    shutil.copy(os.path.join(orig, nome), os.path.join(dest, nome))
print('atividades no periodo', len(validas), '| linhas de relacao', n)
