"""Figuras da secao Resultados: Computacao (Camada 1) e Computacao x Matematica.

Uso: python gerar_figuras_ccmat.py <pasta_com_os_4_csvs_do_periodo> <pasta_de_saida>

Os CSVs de entrada sao os do projeto (backend/data/raw) restritos as atividades
de 2016 a 2026 (ver gerar_periodo.py). O peso W segue backend/src/engine/peso.py:
    W = soma(alfa_d * ln(1 + x_d) / ln(1 + M_d)),  alfa = (0,40; 0,20; 0,20; 0,05; 0,15)
Os grupos da Computacao sao as comunidades de Louvain que analise_rede_IMC.py
encontra no subgrafo da Computacao (Pergunta 3).
"""
import csv
import json
import math
import os
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
import networkx as nx

csv.field_size_limit(10 ** 9)
BASE, SAIDA = sys.argv[1], sys.argv[2]
os.makedirs(SAIDA, exist_ok=True)

ALFA = [0.40, 0.20, 0.20, 0.05, 0.15]
AZUL, LARANJA, CINZA = '#2a78d6', '#eb6834', '#8f8e89'
TINTA, TINTA2, LINHA = '#0b0b0b', '#52514e', '#c9c8c2'
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 7, 'pdf.fonttype': 42,
    'axes.edgecolor': LINHA, 'axes.labelcolor': TINTA2,
    'xtick.color': TINTA2, 'ytick.color': TINTA2,
})


def virgula(x, casas=2):
    return f'{x:.{casas}f}'.replace('.', ',')


# ------------------------------------------------------------------ dados
ent = {r['pesquisador_id']: r for r in csv.DictReader(open(os.path.join(BASE, 'dataset_entrada_IMC.csv'), encoding='utf-8-sig'))}
arestas, nome, inst = {}, {}, {}
for r in csv.DictReader(open(os.path.join(BASE, 'dataset_saida_IMC.csv'), encoding='utf-8-sig')):
    a, b = r['id pesquisador 1'], r['id pesquisador 2']
    arestas[tuple(sorted((a, b)))] = json.loads(r['vetor contagem'])
    nome[a], nome[b] = r['nome do pesquisador 1'], r['nome do pesquisador 2']
    inst[a], inst[b] = r['instituto pesquisador 1'], r['instituto pesquisador 2']
for pid, e in ent.items():
    nome.setdefault(pid, e['nome do pesquisador'])
    inst.setdefault(pid, e['instituto'])
M = [max(v[i] for v in arestas.values()) for i in range(5)]


def peso(v):
    return sum(ALFA[i] * math.log1p(v[i]) / math.log1p(M[i]) for i in range(5))


def area(pid):
    t = (ent.get(pid, {}).get('area de trabalho') or '').lower()
    comp = 'ciência da computação' in t
    mat = 'matemática' in t or 'probabilidade e estatística' in t
    return 'C' if comp and not mat else 'M' if mat and not comp else 'O'


IMC = [p for p, e in ent.items() if e['instituto'] == 'IMC']
G = nx.Graph()
G.add_nodes_from(IMC)
for (a, b), v in arestas.items():
    G.add_edge(a, b, vetor=v, W=peso(v))
for n in G:
    if inst.get(n) == 'IMC':
        G.nodes[n]['area'] = area(n)
    else:
        G.nodes[n]['area'] = 'EXT' if inst.get(n, 'EXT') == 'EXT' or n.startswith('EXT') else 'UNI'
C = [p for p in IMC if area(p) == 'C']
MT = [p for p in IMC if area(p) == 'M']
OU = [p for p in IMC if area(p) == 'O']
G2 = G.subgraph(IMC).copy()
GC = G.subgraph(C).copy()
GM = G.subgraph(MT).copy()

# nome exibido: primeiro nome e sobrenome principal
CURTO = {
    'Rafael de Magalhães Dias Frinhani': 'Rafael Frinhani', 'Bruno Guazzelli Batista': 'Bruno Batista',
    'Melise Maria Veiga de Paula': 'Melise de Paula', 'Vanessa Cristina Oliveira de Souza': 'Vanessa Souza',
    'Adler Diniz de Souza': 'Adler Souza', 'Isabela Neves Drummond': 'Isabela Drummond',
    'Rodrigo Duarte Seabra': 'Rodrigo Seabra', 'Luiz Olmes Carvalho': 'Luiz Carvalho',
    'Alexandre Carlos Brandao Ramos': 'Alexandre Ramos', 'Roberto Claudino da Silva': 'Roberto Claudino',
    'Laércio Augusto Baldochi Júnior': 'Laércio Baldochi', 'Simone de Sousa Borges': 'Simone Borges',
    'João Bosco Schumam Cunha': 'João Bosco Cunha', 'Carlos Minoru Tamaki': 'Carlos Tamaki',
    'Sávio Soares Dias': 'Sávio Dias', 'Laercio Pioli Junior': 'Laercio Pioli',
    'Hevilla Nobre Cezar': 'Hevilla Cezar', 'Rick Antônio Rischter': 'Rick Rischter',
    'Adriana Prest Mattedi': 'Adriana Mattedi', 'Phyllipe de Souza Lima Francisco': 'Phyllipe Francisco',
    'Lucas Ruiz dos Santos': 'Lucas Santos', 'Maicon Sônego': 'Maicon Sônego',
    'Mariana Feiteiro Cavalari Silva': 'Mariana Cavalari', 'Luis Fernando de Osório Mello': 'Luis Fernando Mello',
    'Denis de Carvalho Braga': 'Denis Braga', 'Fabio Scalco Dias': 'Fabio Dias',
    'Luana de Lima Silva Ribeiro': 'Luana Ribeiro', 'Welington da Silva Cordeiro': 'Welington Cordeiro',
    'MAYSA MOTTA FERRAZ': 'Maysa Ferraz', 'Ricardo Iván Medina Bascur': 'Ricardo Bascur',
    'Edisom de Souza Moreira Junior': 'Edisom Moreira Jr.',
}
ID = {nome[p]: p for p in IMC}
curto = lambda p: CURTO.get(nome[p], nome[p].split()[-1])
so_bancas = lambda d: sum(d['vetor']) == d['vetor'][3]

# ------------------------------------------------- figura 1: Computacao
# grupos = comunidades de Louvain de analise_rede_IMC.py no subgrafo da Computacao
GRUPOS = [
    ['Rafael de Magalhães Dias Frinhani', 'Bruno Guazzelli Batista', 'Melise Maria Veiga de Paula',
     'Vanessa Cristina Oliveira de Souza', 'Adler Diniz de Souza', 'Isabela Neves Drummond'],
    ['Rodrigo Duarte Seabra', 'Luiz Olmes Carvalho', 'Laércio Augusto Baldochi Júnior',
     'Simone de Sousa Borges', 'Sávio Soares Dias'],
    ['Alexandre Carlos Brandao Ramos', 'Roberto Claudino da Silva', 'João Bosco Schumam Cunha',
     'Carlos Minoru Tamaki', 'Laercio Pioli Junior'],
]
assert sorted(ID[n] for g in GRUPOS for n in g) == sorted(C)
forca = {p: GC.degree(p, weight='W') for p in C}

# tres agrupamentos (comunidades de Louvain): grupo 1 (nucleo) no alto, grupos 2 e 3 embaixo.
# Posicoes fixas, escolhidas para reduzir cruzamentos; rotulo de cada docente: (dx, dy, alinhamento).
LAYOUT = {
    'Vanessa Souza':    ((0.00, 1.25), (0.00, 0.12, 'center', 'bottom')),
    'Melise de Paula':  ((-0.47, 0.98), (-0.11, 0.00, 'right', 'center')),
    'Isabela Drummond': ((0.47, 0.98), (0.11, 0.00, 'left', 'center')),
    'Rafael Frinhani':  ((-0.47, 0.44), (-0.13, 0.00, 'right', 'center')),
    'Adler Souza':      ((0.47, 0.44), (0.12, 0.00, 'left', 'center')),
    'Bruno Batista':    ((0.00, 0.17), (0.00, -0.13, 'center', 'top')),
    'Rodrigo Seabra':   ((0.82, -0.32), (0.11, 0.00, 'left', 'center')),
    'Luiz Carvalho':    ((0.95, -0.62), (0.10, 0.00, 'left', 'center')),
    'Laércio Baldochi': ((1.00, -0.92), (0.10, 0.00, 'left', 'center')),
    'Simone Borges':    ((0.95, -1.22), (0.09, 0.00, 'left', 'center')),
    'Sávio Dias':       ((0.82, -1.52), (0.08, 0.00, 'left', 'center')),
    'Alexandre Ramos':  ((-0.82, -0.32), (-0.11, 0.00, 'right', 'center')),
    'Roberto Claudino': ((-0.95, -0.62), (-0.10, 0.00, 'right', 'center')),
    'João Bosco Cunha': ((-1.00, -0.92), (-0.09, 0.00, 'right', 'center')),
    'Carlos Tamaki':    ((-0.95, -1.22), (-0.09, 0.00, 'right', 'center')),
    'Laercio Pioli':    ((-0.82, -1.52), (-0.08, 0.00, 'right', 'center')),
}
pos = {p: LAYOUT[curto(p)][0] for p in C}

fig, ax = plt.subplots(figsize=(3.45, 3.75))
ax.set_aspect('equal')
ax.axis('off')
fracas = [(u, v) for u, v, d in GC.edges(data=True) if so_bancas(d)]
fortes = sorted([(u, v, d) for u, v, d in GC.edges(data=True) if not so_bancas(d)], key=lambda e: e[2]['W'])
for u, v in fracas:
    ax.plot(*zip(pos[u], pos[v]), color=LINHA, lw=0.45, zorder=1, solid_capstyle='round')
for u, v, d in fortes:
    ax.plot(*zip(pos[u], pos[v]), color=AZUL, lw=0.5 + 5.0 * d['W'], alpha=0.85, zorder=2, solid_capstyle='round')
for p in C:
    ax.scatter(*pos[p], s=14 + 58 * forca[p], color=AZUL, edgecolor='white', linewidth=0.8, zorder=3)
    (x, y), (dx, dy, ha, va) = pos[p], LAYOUT[curto(p)][1]
    ax.text(x + dx, y + dy, f'{curto(p)}\n({virgula(forca[p])})', ha=ha, va=va, color=TINTA, fontsize=6.0, linespacing=1.05,
            zorder=4, bbox=dict(boxstyle='square,pad=0.04', fc='white', ec='none', alpha=0.8))
Wc = sum(d['W'] for *_, d in GC.edges(data=True))
POS_ROT = [(-1.40, 1.45, 'Grupo 1 (núcleo)', 'left'), (1.20, -1.95, 'Grupo 2', 'center'), (-1.20, -1.95, 'Grupo 3', 'center')]
for g, (x, y, titulo, ha) in zip(GRUPOS, POS_ROT):
    ids = [ID[n] for n in g]
    internas = [GC[u][v] for j, u in enumerate(ids) for v in ids[j + 1:] if GC.has_edge(u, v)]
    subst = sum(1 for d in internas if not so_bancas(d))
    xx = x - 0.62 if ha == 'left' else x
    ax.text(xx, y, f'{titulo}\n{len(internas)} vínculos internos,\n{subst} além de bancas · {virgula(100 * sum(d["W"] for d in internas) / Wc, 0)}% do W',
            ha=ha, va='center', color=TINTA2, fontsize=5.7, linespacing=1.2)
leg = [Line2D([0], [0], color=AZUL, lw=0.5 + 5.0 * 0.1, label='inclui atividade além de bancas (W = 0,1)'),
       Line2D([0], [0], color=AZUL, lw=0.5 + 5.0 * 0.6, label='inclui atividade além de bancas (W = 0,6)'),
       Line2D([0], [0], color=LINHA, lw=0.9, label='só bancas')]
ax.legend(handles=leg, loc='upper center', bbox_to_anchor=(0.5, 0.0), frameon=False, fontsize=5.9,
          handlelength=2.0, ncol=1, labelcolor=TINTA2, borderaxespad=0)
ax.set_xlim(-2.15, 2.15)
ax.set_ylim(-2.25, 1.62)
fig.subplots_adjust(left=0, right=1, top=1, bottom=0.12)
fig.savefig(os.path.join(SAIDA, 'fig20_camada1_computacao.pdf'))
fig.savefig(os.path.join(SAIDA, 'fig20_camada1_computacao.png'), dpi=300)
plt.close(fig)

# ------------------------------------- figura 2a: rede Computacao x Matematica
def girar(posicoes, alvo_ids, direcao):
    """Gira um conjunto de posicoes em torno do centro para que alvo_ids aponte para 'direcao' (rad)."""
    cx = sum(x for x, _ in posicoes.values()) / len(posicoes)
    cy = sum(y for _, y in posicoes.values()) / len(posicoes)
    ax_ = sum(posicoes[p][0] for p in alvo_ids) / len(alvo_ids) - cx
    ay_ = sum(posicoes[p][1] for p in alvo_ids) / len(alvo_ids) - cy
    d = direcao - math.atan2(ay_, ax_)
    cs, sn = math.cos(d), math.sin(d)
    return {p: (cx + (x - cx) * cs - (y - cy) * sn, cy + (x - cx) * sn + (y - cy) * cs) for p, (x, y) in posicoes.items()}


def encaixar(posicoes, centro, raio):
    cx = sum(x for x, _ in posicoes.values()) / len(posicoes)
    cy = sum(y for _, y in posicoes.values()) / len(posicoes)
    r = max(math.hypot(x - cx, y - cy) for x, y in posicoes.values()) or 1
    return {p: (centro[0] + (x - cx) / r * raio, centro[1] + (y - cy) / r * raio) for p, (x, y) in posicoes.items()}


cruz = [(u, v, d) for u, v, d in G2.edges(data=True) if {G2.nodes[u]['area'], G2.nodes[v]['area']} == {'C', 'M'}]
ponta_c = [u if G2.nodes[u]['area'] == 'C' else v for u, v, _ in cruz]
ponta_m = [u if G2.nodes[u]['area'] == 'M' else v for u, v, _ in cruz]

# cada area num circulo, na ordem das comunidades de Louvain de analise_rede_IMC.py;
# as pontas dos vinculos entre as areas ficam viradas para o centro da figura.
ORDEM_C = ['Alexandre Carlos Brandao Ramos', 'João Bosco Schumam Cunha', 'Carlos Minoru Tamaki',
           'Laercio Pioli Junior', 'Sávio Soares Dias', 'Simone de Sousa Borges', 'Laércio Augusto Baldochi Júnior',
           'Luiz Olmes Carvalho', 'Rodrigo Duarte Seabra', 'Isabela Neves Drummond', 'Adler Diniz de Souza',
           'Vanessa Cristina Oliveira de Souza', 'Melise Maria Veiga de Paula', 'Rafael de Magalhães Dias Frinhani',
           'Bruno Guazzelli Batista', 'Roberto Claudino da Silva']
ORDEM_M = ['Rick Antônio Rischter', 'Mariza Stefanello Simsen', 'Leandro Gustavo Gomes', 'Jacson Simsen',
           'Juan Valentín Mendoza Mogollón', 'Ingrid Sofia Meza Sarmiento', 'Giane Casari Rampasso',
           'Fernando Pereira Micena', 'Claudemir Pinheiro de Oliveira', 'Braulio Augusto Garcia',
           'Antonio Carlos Fernandes', 'Nancy Carolina Chachapoyas Siesquén', 'José Humberto Bravo Vidarte',
           'Ronisio Moises Ribeiro', 'Alexander Fernandes da Fonseca', 'Artur César Fassoni', 'Denis de Carvalho Braga',
           'Luis Fernando de Osório Mello', 'Fabio Scalco Dias', 'Gisele Leite da Silva', 'Flavia Sueli Fabiani Marcatto',
           'Eliane Matesco Cristovão', 'Hevilla Nobre Cezar']
sem_vinculo_mat = [p for p in MT if GM.degree(p) == 0]
assert sorted(ID[n] for n in ORDEM_C) == sorted(C)
assert sorted([ID[n] for n in ORDEM_M] + sem_vinculo_mat) == sorted(MT)
POS = {}
# Computacao: de +15 graus (Ramos) no sentido anti-horario ate -15 graus (Claudino)
for k, n in enumerate(ORDEM_C):
    a = math.radians(15 + 330 * k / (len(ORDEM_C) - 1))
    POS[ID[n]] = (-1.85 + 0.80 * math.cos(a), 0.80 * math.sin(a))
# Matematica: de 195 graus (Rischter) no sentido anti-horario ate 165 graus (Cezar)
for k, n in enumerate(ORDEM_M):
    a = math.radians(195 + 330 * k / (len(ORDEM_M) - 1))
    POS[ID[n]] = (1.85 + 1.0 * math.cos(a), 1.0 * math.sin(a))
manual = {'Adriana Mattedi': (-0.55, 0.92), 'Phyllipe Francisco': (-0.55, -0.92), 'Lucas Santos': (0.50, 1.00),
          'Maicon Sônego': (0.50, -1.00), 'Mariana Cavalari': (-0.02, 1.22), 'Ricardo Bascur': (1.10, -1.40),
          'Edisom Moreira Jr.': (-0.05, -1.40), 'Maysa Ferraz': (-1.20, -1.40)}
for p in OU:
    POS[p] = manual[curto(p)]
for i, p in enumerate(sorted(sem_vinculo_mat, key=curto)):
    POS[p] = (1.62, -1.24 - 0.22 * i)

COR = {'C': AZUL, 'M': LARANJA, 'O': CINZA}
MARCA = {'C': 'o', 'M': 's', 'O': '^'}
fig, ax = plt.subplots(figsize=(4.35, 3.35))
ax.set_aspect('equal')
ax.axis('off')
for u, v, d in sorted(G2.edges(data=True), key=lambda e: e[2]['W']):
    au, av = G2.nodes[u]['area'], G2.nodes[v]['area']
    if {au, av} == {'C', 'M'}:
        continue
    cor = COR[au] if au == av and au in 'CM' else CINZA
    ax.plot(*zip(POS[u], POS[v]), color=cor, lw=0.25 + 3.2 * d['W'], alpha=0.32 if cor != CINZA else 0.38,
            zorder=1, solid_capstyle='round')
for u, v, d in cruz:
    ax.plot(*zip(POS[u], POS[v]), color=TINTA, lw=1.4, ls=(0, (3, 2)), zorder=3)
s2 = {p: G2.degree(p, weight='W') for p in IMC}
for a in 'CMO':
    ids = [p for p in IMC if area(p) == a]
    ax.scatter([POS[p][0] for p in ids], [POS[p][1] for p in ids], s=[10 + 28 * s2[p] for p in ids],
               marker=MARCA[a], color=COR[a], edgecolor='white', linewidth=0.6, zorder=4)
ROT = {'Alexandre Ramos': (0.02, 0.13, 'center'), 'Roberto Claudino': (0.02, -0.13, 'center'),
       'Hevilla Cezar': (-0.02, 0.13, 'center'), 'Rick Rischter': (-0.02, -0.13, 'center'),
       'Adriana Mattedi': (0.0, 0.15, 'center'), 'Phyllipe Francisco': (0.0, -0.16, 'center'),
       'Lucas Santos': (0.0, 0.15, 'center'), 'Maicon Sônego': (0.0, -0.16, 'center'),
       'Mariana Cavalari': (0.0, 0.15, 'center'), 'Ricardo Bascur': (0.0, -0.15, 'center'),
       'Edisom Moreira Jr.': (0.0, -0.15, 'center'), 'Maysa Ferraz': (0.0, -0.15, 'center'),
       'Luana Ribeiro': (0.09, 0.0, 'left'), 'Welington Cordeiro': (0.09, 0.0, 'left')}
for p in IMC:
    c = curto(p)
    if c in ROT:
        dx, dy, ha = ROT[c]
        ax.text(POS[p][0] + dx, POS[p][1] + dy, c, ha=ha, va='center', fontsize=6.2, color=TINTA, zorder=5)
# rotulo das duas arestas cruzadas, no meio da figura
for u, v, d in cruz:
    (x1, y1), (x2, y2) = POS[u], POS[v]
    tipo = 'artigo' if d['vetor'][0] else 'banca'
    ym = (y1 + y2) / 2
    dy = 0.30 if ym >= 0.05 else -0.30
    ax.text(0.0, ym + dy, f'1 {tipo}, W = {virgula(d["W"], 3)}', ha='center', va='center', fontsize=6.0,
            color=TINTA, zorder=6)
nCC = GC.number_of_edges()
nMM = GM.number_of_edges()
ax.text(-1.95, 1.27, f'Computação\n{len(C)} docentes · {nCC} vínculos', ha='center', va='bottom', fontsize=6.8,
        color=AZUL, fontweight='bold', linespacing=1.2)
ax.text(1.85, 1.30, f'Matemática\n{len(MT)} docentes · {nMM} vínculos', ha='center', va='bottom', fontsize=6.8,
        color='#c4501f', fontweight='bold', linespacing=1.2)
leg = [Line2D([0], [0], marker='o', color='w', markerfacecolor=AZUL, markersize=5, label=f'Computação ({len(C)})'),
       Line2D([0], [0], marker='s', color='w', markerfacecolor=LARANJA, markersize=5, label=f'Matemática ({len(MT)})'),
       Line2D([0], [0], marker='^', color='w', markerfacecolor=CINZA, markersize=5.5, label=f'Outras / sem área ({len(OU)})'),
       Line2D([0], [0], color=TINTA, lw=1.3, ls=(0, (3, 2)), label=f'Computação–Matemática ({len(cruz)})')]
ax.legend(handles=leg, loc='upper center', bbox_to_anchor=(0.5, -0.025), ncol=2, frameon=False, fontsize=6.2,
          columnspacing=1.2, handletextpad=0.4, labelcolor=TINTA2, borderaxespad=0)
ax.set_xlim(-2.95, 2.95)
ax.set_ylim(-1.62, 1.75)
fig.subplots_adjust(left=0, right=1, top=1, bottom=0.14)
fig.savefig(os.path.join(SAIDA, 'fig21_computacao_vs_matematica.pdf'))
fig.savefig(os.path.join(SAIDA, 'fig21_computacao_vs_matematica.png'), dpi=300)
plt.close(fig)

# --------------------------------------- figura 2b: densidade entre os blocos
grupos = [('Computação', C), ('Matemática', MT), ('Outras', OU)]
W2 = sum(d['W'] for *_, d in G2.edges(data=True))
fig, ax = plt.subplots(figsize=(2.55, 2.45))
azuis = LinearSegmentedColormap.from_list('azuis', ['#f4f8fd', '#9cc2ec', '#2a78d6', '#0d3f80'])
dmax = 0.7
for i, (ni, gi) in enumerate(grupos):
    for j, (nj, gj) in enumerate(grupos):
        if j > i:
            continue
        if i == j:
            e = G2.subgraph(gi).number_of_edges()
            poss = len(gi) * (len(gi) - 1) / 2
            w = sum(d['W'] for *_, d in G2.subgraph(gi).edges(data=True))
        else:
            pares = [(u, v) for u in gi for v in gj if G2.has_edge(u, v)]
            e = len(pares)
            poss = len(gi) * len(gj)
            w = sum(G2[u][v]['W'] for u, v in pares)
        dens = e / poss
        cor = azuis(min(dens / dmax, 1.0))
        ax.add_patch(plt.Rectangle((j, -i - 1), 0.96, 0.96, color=cor, lw=0))
        claro = dens / dmax > 0.45
        tc = 'white' if claro else TINTA
        ax.text(j + 0.48, -i - 0.30, virgula(dens, 3), ha='center', va='center', fontsize=8.2, fontweight='bold', color=tc)
        ax.text(j + 0.48, -i - 0.56, f'{e} vínculo' + ('s' if e != 1 else ''), ha='center', va='center', fontsize=5.9, color=tc)
        ax.text(j + 0.48, -i - 0.76, f'{virgula(100 * w / W2, 1)}% do W', ha='center', va='center', fontsize=5.9, color=tc)
for k, (n, g) in enumerate(grupos):
    ax.text(-0.06, -k - 0.52, f'{n}\n({len(g)})', ha='right', va='center', fontsize=6.4, color=TINTA, linespacing=1.15)
    ax.text(k + 0.48, -3.08, f'{n}\n({len(g)})', ha='center', va='top', fontsize=6.4, color=TINTA, linespacing=1.15)
ax.set_xlim(-0.95, 2.98)
ax.set_ylim(-3.5, 0.02)
ax.set_aspect('equal')
ax.axis('off')
fig.subplots_adjust(left=0.01, right=0.99, top=0.99, bottom=0.01)
fig.savefig(os.path.join(SAIDA, 'fig23_densidade_entre_areas.pdf'))
fig.savefig(os.path.join(SAIDA, 'fig23_densidade_entre_areas.png'), dpi=300)
plt.close(fig)

# ---------------------------------------- figura 3: forca media por destino
def destino(p, q):
    a = G.nodes[q]['area']
    if a == G.nodes[p]['area']:
        return 0
    if a in ('C', 'M'):
        return 1
    if a == 'O':
        return 2
    return 3 if a == 'UNI' else 4


ROTULOS = ['Mesma área', 'Outra área do IMC', 'Docentes do IMC de\noutras áreas', 'Outros institutos\nda UNIFEI', 'Externos']
medias = {}
for nm_, grupo in [('Computação', C), ('Matemática', MT)]:
    soma = [0.0] * 5
    for p in grupo:
        for q in G[p]:
            soma[destino(p, q)] += G[p][q]['W']
    medias[nm_] = [s / len(grupo) for s in soma]
fig, ax = plt.subplots(figsize=(3.45, 1.70))
alt = 0.36
for k, (nm_, cor) in enumerate([('Computação', AZUL), ('Matemática', LARANJA)]):
    ys = [len(ROTULOS) - 1 - i + (alt / 2 + 0.02 if k == 0 else -alt / 2 - 0.02) for i in range(len(ROTULOS))]
    ax.barh(ys, medias[nm_], height=alt, color=cor, label=nm_, zorder=2)
    for y, val in zip(ys, medias[nm_]):
        ax.text(val + 0.03, y, virgula(val, 3) if val < 0.01 else virgula(val), va='center', ha='left', fontsize=6.2, color=TINTA)
ax.set_yticks(range(len(ROTULOS)))
ax.set_yticklabels(list(reversed(ROTULOS)), fontsize=6.4, color=TINTA)
ax.tick_params(axis='y', length=0)
ax.tick_params(axis='x', labelsize=6.2)
ax.set_xlim(0, 2.1)
ax.set_xticks([0, 0.5, 1.0, 1.5, 2.0])
ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda x, _: virgula(x, 1)))
ax.grid(axis='x', color='#ececea', lw=0.6, zorder=0)
for s in ('top', 'right', 'left'):
    ax.spines[s].set_visible(False)
ax.set_xlabel('Força média por docente (soma de W)', fontsize=6.4)
ax.legend(loc='upper right', bbox_to_anchor=(1.0, 0.80), frameon=False, fontsize=6.4, labelcolor=TINTA2)
fig.subplots_adjust(left=0.30, right=0.98, top=0.98, bottom=0.21)
fig.savefig(os.path.join(SAIDA, 'fig22_forca_por_destino.pdf'))
fig.savefig(os.path.join(SAIDA, 'fig22_forca_por_destino.png'), dpi=300)
plt.close(fig)

print('M =', M, '| arestas =', G.number_of_edges(), '| C, M, O =', len(C), len(MT), len(OU))
print('forca media por destino:', {k: [round(x, 3) for x in v] for k, v in medias.items()})
print('cruzadas:', [(nome[u], nome[v], round(d['W'], 4), d['vetor']) for u, v, d in cruz])
